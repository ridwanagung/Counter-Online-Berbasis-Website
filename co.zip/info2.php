<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>Counter Online</title>
		<link rel="icon" href="images/Counter Online Logo1.png" type="image/x-icon">
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <link href="styles.css" rel="stylesheet" type="text/css" media="screen" />
    </head>
    <body>
        <div id="wrap">
            <div id="header">
                <div id="logo">
                    <img style=" border:opx;width:150px;height:130px;margin:0px 0px 30px 0px"src ="images/Counter Online Logo1.png" > 
					<img style=" border:opx;width:450px;height:80px;margin:0px 0px 30px 0px"src ="images/Counter Online Header.png" >
                </div>
                <div id="menu">
                    <ul>
                        <li><a href="index.html" class="active">Home</a></li>
                        <li><a href="aboutus.html">About Us</a></li>
                        <li><a href="gallery.html">Merk HP</a></li>
                        <li><a href="license.html">Aksesoris</a></li>
                        <li><a href="contact.html">Contact Us</a></li>
                    </ul>
                </div>
            </div>
            <div id="prev">
               
            </div>

            <div id="content">
                <div class="about">
                    <h4>Team Info</h4><br>
                     <div class="news_left">
							<img src="images/img2.jpg" alt="" title="" style="border:0px;width:150px;height:150px; float: left; padding-right: 15px; padding-bottom: 10px;"/>
							<p><a href="info2.php"> Mohamad Iqbal Khilmi | Editor. </a><br />
								Lahir pada 1998 di Kab. Pekalongan, dia bekerja diTeam ini sebagai Editor tampilan, keahliannya dibidang teknologi ini sangat...</p><br>
							 <div class="read"><a href="index.html">Back<img src="images/back.png" alt="" title=""/></a></div>
							<div style="clear: both"></div>
                     </div>
                </div>
                <div style="clear: both"></div>
            </div>
            <div class="con_bot"></div>
            
            <div id="footer">
                <div class="red_hr"></div>
                  <p>Copyright  2017.  | <a href="#">Counter Online</a> | <a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional"><abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a> | <a href="http://jigsaw.w3.org/css-validator/check/referer" title="This page validates as CSS"><abbr title="Cascading Style Sheets">CSS</abbr></a></p></div>
        </div>
    </body>
</html>
